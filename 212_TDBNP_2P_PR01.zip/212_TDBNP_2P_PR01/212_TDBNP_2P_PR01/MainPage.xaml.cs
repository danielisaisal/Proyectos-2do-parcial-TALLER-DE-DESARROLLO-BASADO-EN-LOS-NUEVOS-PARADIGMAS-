﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace _212_TDBNP_2P_PR01
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            cmbPorcentajeISR.Opacity = 0;
            cmbPorcentajeIEPS.Opacity = 0;
            cmbPorcentajeIVA.Opacity = 0;                    
            cmbPorcentajeIVA.IsEnabled = false;
            cmbPorcentajeISR.IsEnabled = false;
            cmbPorcentajeIEPS.IsEnabled = false;
            imgIVA.Opacity = 0;
            imgIEPS.Opacity = 0;
            imgISR.Opacity = 0;
        }
        double total=0, dinero;
        
        private void btnDato_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void cmbTazas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (this.cmbTazas.SelectedIndex)
            {
                case 0:
                    cmbPorcentajeISR.Opacity = 0;
                    cmbPorcentajeIEPS.Opacity = 0;
                    cmbPorcentajeIVA.Opacity = 100;
                    cmbPorcentajeIVA.IsEnabled = true;
                    cmbPorcentajeISR.IsEnabled = false;
                    cmbPorcentajeIEPS.IsEnabled = false;
                    imgIVA.Opacity = 100;
                    imgIEPS.Opacity = 0;
                    imgISR.Opacity = 0;
                    break;
                case 1:
                    cmbPorcentajeISR.Opacity = 100;
                    cmbPorcentajeIEPS.Opacity = 0;
                    cmbPorcentajeIVA.Opacity = 0;
                    cmbPorcentajeISR.IsEnabled = true;
                    cmbPorcentajeIVA.IsEnabled = false;
                    cmbPorcentajeIEPS.IsEnabled = false;
                    imgISR.Opacity = 100;
                    imgIEPS.Opacity = 0;
                    imgIVA.Opacity = 0;
                    break;
                case 2:
                    cmbPorcentajeISR.Opacity = 0;
                    cmbPorcentajeIEPS.Opacity = 100;
                    cmbPorcentajeIVA.Opacity = 0;
                    cmbPorcentajeIEPS.IsEnabled = true;
                    cmbPorcentajeIVA.IsEnabled = false;
                    cmbPorcentajeISR.IsEnabled = false;
                    imgIEPS.Opacity = 100;
                    imgIVA.Opacity = 0;
                    imgISR.Opacity = 0;
                    break;
                    
                default:
                    break;
            }
        }

        private void cmbPorcentajeIVA_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double total=0;
            double dinero = double.Parse(txtDinero.Text);
            switch (this.cmbPorcentajeIVA.SelectedIndex) {
                case 0:
                    total = dinero + (dinero * 0.11);
                    break;
                case 1:
                    total = dinero + (dinero * 0.16);
                    break;
            }
            txtTotal.Text = ""+total;
            
        }

        private void cmbPorcentajeIVA_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            total = 0;
            dinero = double.Parse(txtDinero.Text);
            switch (this.cmbPorcentajeIVA.SelectedIndex)
            {
                case 0:
                    total = dinero + (dinero * 0.11);
                    break;
                case 1:
                    total = dinero + (dinero * 0.16);
                    break;
            }
            txtTotal.Text = "El total es: " + total;
        }

        private void cmbPorcentajeIEPS_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            total = 0;
            dinero = double.Parse(txtDinero.Text);
            switch (this.cmbPorcentajeIEPS.SelectedIndex)
            {
                case 0:
                    total = dinero + (dinero * 0.02);
                    break;
                case 1:
                    total = dinero + (dinero * 0.03);
                    break;
                case 2:
                    total = dinero + (dinero * 0.04);
                    break;
            }
            txtTotal.Text = "El total es: " + total;
        }

        private void stwDark_Toggled(object sender, RoutedEventArgs e)
        {
            SolidColorBrush brushHeader;
            SolidColorBrush brushTitulo;
            if (this.stwDark.IsOn)
            {
                brushHeader = new SolidColorBrush(Color.FromArgb(255, 10, 10, 10));
                brushTitulo = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));
            }
            else
            {
                brushHeader = new SolidColorBrush(Color.FromArgb(255, 115, 0, 182));
                brushTitulo = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
            }
            this.rctCabeza.Fill = brushHeader;
            this.txtTitulo.Foreground = brushTitulo;
        }

        private void cmbPorcentajeISR_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            total = 0;
            dinero = double.Parse(txtDinero.Text);
            switch (this.cmbPorcentajeISR.SelectedIndex)
            {
                case 0:
                    total = dinero + (dinero * 0.25);
                    break;
                case 1:
                    total = dinero + (dinero * 0.30);
                    break;
                case 2:
                    total = dinero + (dinero * 0.20);
                    break;
            }
            txtTotal.Text = "El total es: " + total;
        }
    }
}
