﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Media.Imaging;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace _212_TDBNP_PR2_2P
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            cmbImg2.Opacity = 0;
            cmbImg2.IsEnabled = false;
        }
        int cont=1;
        private void btnLeft_Click(object sender, RoutedEventArgs e)
        {
            if (swtCambiar.IsOn)
            {
                if (cont > 1)
                {
                    cont--;
                }
                else
                {
                    cont = 4;
                }
                this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/Eevee_0{cont}.png"));
            }
            else
            {
                if (cont > 1)
                {
                    cont--;
                }
                else
                {
                    cont = 4;
                }
                this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/gengar_0{cont}.png"));
            }

            CambiaSubtitulo(cont);
        }
        public void CambiaSubtitulo(int cont)
        {
            if (swtCambiar.IsOn)
            {
                switch (cont)
                {
                    case 1:
                        this.txtDescription.Text = "Eevee";
                        break;
                    case 2:
                        this.txtDescription.Text = "Espeon";
                        break;
                    case 3:
                        this.txtDescription.Text = "Silveon";
                        break;
                    case 4:
                        this.txtDescription.Text = "Leafeon";
                        break;
                    default:
                        this.txtDescription.Text = "Sin descripcción";
                        break;
                }
            }
            else
            {
                switch (cont)
                {
                    case 1:
                        this.txtDescription.Text = "Gastly";
                        break;
                    case 2:
                        this.txtDescription.Text = "Haunter";
                        break;
                    case 3:
                        this.txtDescription.Text = "Gengar";
                        break;
                    case 4:
                        this.txtDescription.Text = "Mega Gengar";
                        break;
                    default:
                        this.txtDescription.Text = "Sin descripcción";
                        break;
                }

            }
            

        }

        private void btnRight_Click(object sender, RoutedEventArgs e)
        {
            if (swtCambiar.IsOn)
            {
                if (cont < 4)
                {
                    cont++;
                }
                else
                {
                    cont = 1;
                }
                this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/Eevee_0{cont}.png"));
            }
            else
            {
                if (cont < 4)
                {
                    cont++;
                }
                else
                {
                    cont = 1;
                }
                this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/gengar_0{cont}.png"));

            }


            
            
            
            CambiaSubtitulo(cont);
        }

        private void cmbImg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cont = this.cmbImg.SelectedIndex + 1;
            this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/gengar_0{cont}.png"));
            CambiaSubtitulo(cont);
        }

        private void swtCambiar_Toggled(object sender, RoutedEventArgs e)
        {
           
            if (swtCambiar.IsOn)
            {
                cmbImg2.IsEnabled = true;
                cmbImg.Opacity = 0;
                cmbImg2.Opacity = 100;
                cmbImg.IsEnabled = false;

            }
            else
            {
                cmbImg.Opacity = 100;
                cmbImg2.Opacity = 0;
                cmbImg.IsEnabled = true;
                cmbImg2.IsEnabled = false;
            }
            
        }

        private void cmbImg2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cont = this.cmbImg2.SelectedIndex + 1;
            this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/Eevee_0{cont}.png"));
            CambiaSubtitulo(cont);
        }
    }
}
