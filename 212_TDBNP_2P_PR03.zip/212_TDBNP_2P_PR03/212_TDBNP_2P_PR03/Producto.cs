﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _212_TDBNP_2P_PR03
{
    class Producto
    {
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public int codigo { get; set; }
        public double precio { get; set; }
        public string imagen { get; set; }

        public Producto()
        {
            nombre = "";
            imagen = "";
            descripcion = "";
            codigo = 0;
            precio = 0;
        }
        public Producto(string _nombre, string _imagen, string _descripcion, int _codigo, double _precio) {
            nombre = _nombre;
            imagen = _imagen;
            descripcion = _descripcion;
            codigo = _codigo;
            precio = _precio;
        }

    }
}
