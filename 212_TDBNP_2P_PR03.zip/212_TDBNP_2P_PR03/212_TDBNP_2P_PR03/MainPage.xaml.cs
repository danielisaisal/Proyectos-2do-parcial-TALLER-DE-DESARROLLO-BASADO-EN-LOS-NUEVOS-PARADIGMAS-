﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace _212_TDBNP_2P_PR03
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        List<Producto> lstImgs = new List<Producto>();
        int cont = 0;
        public MainPage()
        {
            this.InitializeComponent();
            

            lstImgs.Add(new Producto("Adventure", "ms-appx:///Assets/images/adventure.jpg", "Vinilo adventure", 003421, 1500));
            lstImgs.Add(new Producto("Good faith", "ms-appx:///Assets/images/Madeon.jpg", "Vinilo Good faith", 854964, 2300));
            lstImgs.Add(new Producto("Darken", "ms-appx:///Assets/images/zutomayo-darken.jpg", "Vinilo Zutomayo Darken", 663532, 2000.50));
            lstImgs.Add(new Producto("Worlds", "ms-appx:///Assets/images/worls.jpg", "Vinilo Worlds", 735461, 1500.50));
            lstImgs.Add(new Producto("Nurture", "ms-appx:///Assets/images/nurture.jpg", "Vinilo Nurture", 111231, 1800));
            
            foreach (Producto x in lstImgs)
            {
                this.cmbProductos.Items.Add(x.nombre);
            }
        }

        private void cmbProductos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string acu="", acu2="";
            cont = this.cmbProductos.SelectedIndex;
            int index = cont;
            this.imgVinilos.Source = new BitmapImage(new Uri(lstImgs[index].imagen));
            this.txtIntruccion.Text = lstImgs[index].nombre;
            this.txtDescVinilo.Text = lstImgs[index].descripcion;
            acu += "Precio: " + lstImgs[index].precio;
            this.txtPrecio.Text = acu;
            acu2 += "Codigo: " + lstImgs[index].codigo;
            this.txtCodigo.Text = acu2;

        }

        private void btnIzquierda_Click(object sender, RoutedEventArgs e)
        {
            string acu = "", acu2 = "";
            if (cont < 4)
            {
                cont++;
            }
            else
            {
                cont = 0;
            }
            int index = cont;
            imgVinilos.Source = new BitmapImage(new Uri (lstImgs[index].imagen));
            this.txtIntruccion.Text = lstImgs[index].nombre;
            this.txtDescVinilo.Text = lstImgs[index].descripcion;
            acu += "Precio: " + lstImgs[index].precio;
            this.txtPrecio.Text = acu;
            acu2 += "Codigo: " + lstImgs[index].codigo;
            this.txtCodigo.Text = acu2;
        }

        private void btnDerecha_Click(object sender, RoutedEventArgs e)
        {
            string acu = "", acu2 = "";
            if (cont > 1)
            {
                cont--;
            }
            else
            {
                cont = 4;
            }
            int index = cont;
            imgVinilos.Source = new BitmapImage(new Uri(lstImgs[index].imagen));
            this.txtIntruccion.Text = lstImgs[index].nombre;
            this.txtDescVinilo.Text = lstImgs[index].descripcion;
            acu += "Precio: " + lstImgs[index].precio;
            this.txtPrecio.Text = acu;
            acu2 += "Codigo: " + lstImgs[index].codigo;
            this.txtCodigo.Text = acu2;
        }
        double acu3 = 0;
        private void btnAgregar_Click(object sender, RoutedEventArgs e)
        {
            
            this.lsvPrincipal.Items.Add(this.lstImgs[cont].nombre);
            acu3 += lstImgs[cont].precio;
            txtAcumulable.Text = $"Total: ${acu3}";
        }
    }
}
