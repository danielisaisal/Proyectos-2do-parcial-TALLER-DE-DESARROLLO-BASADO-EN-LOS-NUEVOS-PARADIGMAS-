﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Media.Imaging;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace _212_TDBNP_2P_EJ02
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        int cont = 1;
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void btnRight_Click(object sender, RoutedEventArgs e)
        {
            
            if (cont < 4)
            {
                cont++;
            }
            else
            {
                cont = 1;
            }
            this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/gengar_0{cont}.png"));
            CambiaSubtitulo(cont);
        }

        public void CambiaSubtitulo(int cont) { 
            switch (cont)
            {
                case 1:
                    this.txtDescription.Text = "Gastly";
                    break;
                case 2:
                    this.txtDescription.Text = "Haunter";
                    break;
                case 3:
                    this.txtDescription.Text = "Gengar";
                    break;
                case 4:
                    this.txtDescription.Text = "Mega Gengar";
                    break;
                default:
                    this.txtDescription.Text = "Sin descripcción";
                    break;
            }
        
        }

        private void btnLeft_Click(object sender, RoutedEventArgs e)
        {
            if (cont > 1)
            {
                cont--;
            }
            else
            {
                cont = 4;
            }
            this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/gengar_0{cont}.png"));
            CambiaSubtitulo(cont);
        }

        private void cmbImg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cont = this.cmbImg.SelectedIndex + 1;
            this.imgPrincipal.Source = new BitmapImage(new Uri($"ms-appx:///Assets/gengar_0{cont}.png"));
            CambiaSubtitulo(cont);
        }
    }
}
