﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace _212_TDBNP_3P_EJ01
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        DateTime ahora;
        DateTime hoy;
        DateTime formato;
        DateTime hora;
        DateTime personal;
        DispatcherTimer timer;
        public MainPage()
        {
            this.InitializeComponent();

            ahora = DateTime.Now;
            hoy = DateTime.Today;
            formato = DateTime.Now;
            hora = DateTime.Now;
            personal = new DateTime(2022,2,15,16,47,0);

            this.txtAhora.Text = ahora.ToString();
            this.txtFecha.Text = hoy.ToString();
            this.txtFormato.Text = formato.ToString("yyyy-MM-dd");
            this.txtHora.Text = hora.ToString("HH:mm:ss");

            timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(0,0,1);
            timer.Tick += dispatcherTimer_Tick;
            timer.Start();
        }

        void dispatcherTimer_Tick(object sender, object e) {
            this.txtTimer.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void dtpFecha_DateChanged(object sender, DatePickerValueChangedEventArgs e)
        {
            DateTime dtp = dtpFecha.SelectedDate.Value.DateTime;
            this.txtFechaDTP.Text = dtp.ToString("yyyy-MM-dd");
            this.txtDif.Text = $"{(hoy - dtp).Days.ToString()}" +
                $"/ Años: {hoy.Year - dtp.Year}" +
                $"/ Meses: {hoy.Month - dtp.Month} " +
                $"/Días: {hoy.Day - dtp.Day}";
        }

        private void btnValidar_Click(object sender, RoutedEventArgs e)
        {
            int year = int.Parse(this.txtYear.Text);
            if (DateTime.IsLeapYear(year))
            {
                this.txtBisiesto.Text = "SI";
            }
            else
            {
                this.txtBisiesto.Text = "NO";
            }
        }
    }
}
