﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace _212_TDBNP_3P_EJ03
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();

            

            RepeatBehavior rb = new RepeatBehavior();
            rb.Type = RepeatBehaviorType.Forever;
            sbHighLight1.RepeatBehavior = rb;
            sbHighLigth2.RepeatBehavior = rb;
            sbHigtLight3.RepeatBehavior = rb;
            sbAzul1.RepeatBehavior = rb;
            sbAzul2.RepeatBehavior = rb;
            sbAzul3.RepeatBehavior = rb;
            sbVerde1.RepeatBehavior = rb;
            sbVerde2.RepeatBehavior = rb;
            sbVerde3.RepeatBehavior = rb;
            //this.sbInicio.Begin();

            //RepeatBehavior rb2 = new RepeatBehavior(2);
            //this.sbBall.RepeatBehavior = rb2;
            this.sbHighLight1.Begin();
            this.sbHighLigth2.Begin();
            this.sbHigtLight3.Begin();
            this.sbAzul1.Begin();
            this.sbAzul2.Begin();
            this.sbAzul3.Begin();
            this.sbVerde1.Begin();
            this.sbVerde2.Begin();
            this.sbVerde3.Begin();
        }
    }
}
